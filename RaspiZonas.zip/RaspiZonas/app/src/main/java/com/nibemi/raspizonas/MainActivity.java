package com.nibemi.raspizonas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    Button cerrar, guardar_horario;
    EditText ip, horario;
    ToggleButton zona1, zona2, zona3, zona4;
    WebService web = new WebService();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        zona1 = (ToggleButton)findViewById(R.id.zona1);
        zona2 = (ToggleButton)findViewById(R.id.zona2);
        zona3 = (ToggleButton)findViewById(R.id.zona3);
        zona4 = (ToggleButton)findViewById(R.id.zona4);

        ip = (EditText)findViewById(R.id.ip);
        horario = (EditText)findViewById(R.id.horario);

        guardar_horario = (Button)findViewById(R.id.guardar_horario);
        cerrar = (Button)findViewById(R.id.cerrar);

        zona1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String host = ip.getText().toString();
                final Boolean estado = zona1.isChecked();

                Thread tr = new Thread(){
                    @Override
                    public void run() {

                        final String datos = web.Zonas(host,1, estado);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try{
                                    JSONArray elementos = new JSONArray(datos);

                                    if (elementos.length()>0) {
                                        for (int i = 0; i < elementos.length(); i++) {
                                            JSONObject jsonobject = elementos.getJSONObject(i);
                                            String valor = jsonobject.getString("valor");
                                            String respuesta = jsonobject.getString("respuesta");

                                            Toast.makeText(getApplicationContext(), respuesta, Toast.LENGTH_SHORT).show();
                                        }
                                    }else{
                                        Toast.makeText(getApplicationContext(), "No se pudo activar/desactivar la zona.", Toast.LENGTH_SHORT).show();
                                    }

                                }catch(Exception e){
                                    System.out.println(e.getMessage());
                                }

                            }
                        });
                    }
                };
                tr.start();
            }
        });

        zona2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String host = ip.getText().toString();
                final Boolean estado = zona2.isChecked();

                Thread tr = new Thread(){
                    @Override
                    public void run() {

                        final String datos = web.Zonas(host,2, estado);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try{
                                    JSONArray elementos = new JSONArray(datos);

                                    if (elementos.length()>0) {
                                        for (int i = 0; i < elementos.length(); i++) {
                                            JSONObject jsonobject = elementos.getJSONObject(i);
                                            String valor = jsonobject.getString("valor");
                                            String respuesta = jsonobject.getString("respuesta");

                                            Toast.makeText(getApplicationContext(), respuesta, Toast.LENGTH_SHORT).show();
                                        }
                                    }else{
                                        Toast.makeText(getApplicationContext(), "No se pudo activar/desactivar la zona.", Toast.LENGTH_SHORT).show();
                                    }

                                }catch(Exception e){
                                    System.out.println(e.getMessage());
                                }

                            }
                        });
                    }
                };
                tr.start();
            }
        });

        zona3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String host = ip.getText().toString();
                final Boolean estado = zona3.isChecked();

                Thread tr = new Thread(){
                    @Override
                    public void run() {

                        final String datos = web.Zonas(host,3, estado);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try{
                                    JSONArray elementos = new JSONArray(datos);

                                    if (elementos.length()>0) {
                                        for (int i = 0; i < elementos.length(); i++) {
                                            JSONObject jsonobject = elementos.getJSONObject(i);
                                            String valor = jsonobject.getString("valor");
                                            String respuesta = jsonobject.getString("respuesta");

                                            Toast.makeText(getApplicationContext(), respuesta, Toast.LENGTH_SHORT).show();
                                        }
                                    }else{
                                        Toast.makeText(getApplicationContext(), "No se pudo activar/desactivar la zona.", Toast.LENGTH_SHORT).show();
                                    }

                                }catch(Exception e){
                                    System.out.println(e.getMessage());
                                }

                            }
                        });
                    }
                };
                tr.start();
            }
        });

        zona4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String host = ip.getText().toString();
                final Boolean estado = zona4.isChecked();

                Thread tr = new Thread(){
                    @Override
                    public void run() {

                        final String datos = web.Zonas(host,4, estado);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try{
                                    JSONArray elementos = new JSONArray(datos);

                                    if (elementos.length()>0) {
                                        for (int i = 0; i < elementos.length(); i++) {
                                            JSONObject jsonobject = elementos.getJSONObject(i);
                                            String valor = jsonobject.getString("valor");
                                            String respuesta = jsonobject.getString("respuesta");

                                            Toast.makeText(getApplicationContext(), respuesta, Toast.LENGTH_SHORT).show();
                                        }
                                    }else{
                                        Toast.makeText(getApplicationContext(), "No se pudo activar/desactivar la zona.", Toast.LENGTH_SHORT).show();
                                    }

                                }catch(Exception e){
                                    System.out.println(e.getMessage());
                                }

                            }
                        });
                    }
                };
                tr.start();
            }
        });

        guardar_horario.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                final String host = ip.getText().toString();
                final String hora = horario.getText().toString();

                Thread tr = new Thread(){
                    @Override
                    public void run() {

                        final String datos = web.Configurar_Hora(host, hora);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try{
                                    JSONArray elementos = new JSONArray(datos);

                                    if (elementos.length()>0) {
                                        for (int i = 0; i < elementos.length(); i++) {
                                            JSONObject jsonobject = elementos.getJSONObject(i);
                                            String respuesta = jsonobject.getString("respuesta");

                                            Toast.makeText(getApplicationContext(), respuesta, Toast.LENGTH_SHORT).show();
                                        }
                                    }else{
                                        Toast.makeText(getApplicationContext(), "No se pudo configurar la hora.", Toast.LENGTH_SHORT).show();
                                    }

                                }catch(Exception e){
                                    System.out.println(e.getMessage());
                                }

                            }
                        });
                    }
                };
                tr.start();
            }
        });

        cerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
