package com.nibemi.raspizonas;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class WebService {

    public String Zonas(String host, int rele, Boolean estado){

        int std = 0;
        if (estado){
            std = 1;
        }
        String parametros = "rele="+String.valueOf(rele)+"&estado="+String.valueOf(std);

        HttpURLConnection conexion = null;
        String respuesta = "";

        try{
            URL url = new URL("http://"+host+"/raspizonas/reles.php");
            conexion = (HttpURLConnection)url.openConnection();
            conexion.setRequestMethod("POST");
            conexion.setRequestProperty("Content-Length", ""+Integer.toString(parametros.getBytes().length));
            conexion.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(conexion.getOutputStream());
            wr.writeBytes(parametros);
            wr.close();

            Scanner inStream = new Scanner(conexion.getInputStream());
            while(inStream.hasNextLine()){
                respuesta +=(inStream.nextLine());
            }
        }catch(Exception e){
            //respuesta = e.getMessage();
            System.out.println(e.getMessage().toString());
        }
        return respuesta.toString();
    }

    public String Configurar_Hora(String host, String hora){
        String parametros = "hora="+hora;

        HttpURLConnection conexion = null;
        String respuesta = "";

        try{
            URL url = new URL("http://"+host+"/raspizonas/hora.php");
            conexion = (HttpURLConnection)url.openConnection();
            conexion.setRequestMethod("POST");
            conexion.setRequestProperty("Content-Length", ""+Integer.toString(parametros.getBytes().length));
            conexion.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(conexion.getOutputStream());
            wr.writeBytes(parametros);
            wr.close();

            Scanner inStream = new Scanner(conexion.getInputStream());
            while(inStream.hasNextLine()){
                respuesta +=(inStream.nextLine());
            }
        }catch(Exception e){
            //respuesta = e.getMessage();
            System.out.println(e.getMessage().toString());
        }
        return respuesta.toString();
    }

}